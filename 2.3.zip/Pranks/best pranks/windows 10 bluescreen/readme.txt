if you really want to annoy your friends, put finish.vbs and the bluescreen in the same place!

also f7 to close out the bluescreen (you might need to click on the bluescreen first)